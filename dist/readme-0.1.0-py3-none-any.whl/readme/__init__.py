from jinja2 import Environment, PackageLoader, select_autoescape


def get_environment():
    return Environment(loader=PackageLoader("readme"), autoescape=select_autoescape())