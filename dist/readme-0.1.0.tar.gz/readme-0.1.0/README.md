- 👋 Hi, I’m @gekitsuu
- 👀 I’m interested in security, Python, 3d Modeling, learning, teaching, and growing. 
- 🌱 I’m currently learning how to be a better manager
- 💞️ I’m looking to collaborate about making better leaders
- 📫 How to reach me @gekitsuu on Twitter

<!---
gekitsuu/gekitsuu is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
